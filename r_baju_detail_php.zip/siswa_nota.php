 <script src="src/js/jscal2.js"></script>
    <script src="src/js/lang/en.js"></script>
    <link rel="stylesheet" type="text/css" href="src/css/jscal2.css" />
    <link rel="stylesheet" type="text/css" href="src/css/border-radius.css" />
    <link rel="stylesheet" type="text/css" href="src/css/steel/steel.css" />


<? 
// Sisten Informasi Sanggar LIZA
// Written by agusari@gmail.com
// 10 Oktober 2010, lastupdate 10 Oktober 2010

include_once("include.php");
if($id_siswa=="")$id_siswa=$id;
$sekarang = date('Y-m-d H:i:s');
$sql="select date_format(a.tanggal,'%d-%m-%Y') tgl_acara,a.tanggal,b.acara,c.nama_siswa,c.alamat from tb_acara_workshop a, p_acara b, tb_siswa c where a.id_siswa='$id_siswa' and a.id_acara=b.id_acara and a.id_siswa=c.id_siswa";
$urut=mysql_query("SELECT MAX(no_urut) as no_urut FROM tb_siswa_bayar");
$no_urut=mysql_result($urut,0,"no_urut");
$no_urut+=1;

$kw=mysql_query("SELECT MAX(no_kw) as no_kw FROM tb_siswa_bayar 
where date_format(tanggal,'%Y')=date_format(curdate(),'%Y')");
$no_kw=mysql_result($kw,0,"no_kw");
$no_kw+=1;



//echo $sql;
$rs=@mysql_query($sql);
$n=mysql_num_rows($rs);
if($n==0)
{ 
?>
<br><br><br>
<table cellpadding=3 cellspacing=0 style="border-width: 4px;  border-style: double;">
<tr><td colspan="2">-- <strong><em>BELUM ADA TAGIHAN</em></strong> --</td></tr></table><br>
<?	
}
else
{
$tgl_acara=mysql_result($rs,0,"tgl_acara");
$tgl=mysql_result($rs,0,"tanggal");
?>
<br><br><br>
<table cellpadding=3 cellspacing=0 style="border-width: 4px;  border-style: double;">
<tr><td>Client</td><td colspan=3>: <?=mysql_result($rs,0,"nama_siswa")?></td></tr>
<? for($a=0;$a<@mysql_num_rows($rs);$a++){?>
<tr><td>Tanggal</td><td>: <?=mysql_result($rs,$a,"tgl_acara");?></td><td>: <?=mysql_result($rs,$a,"acara")?></td></tr>
<? } 
$sql="select sum(jumlah) total, sum(diskon) diskon
	from 
	(
	SELECT SUM( harga_paket ) jumlah,'0' diskon
	FROM tb_acara_workshop a, paket b
	WHERE id_siswa ='$id_siswa'
	AND a.id_paket = b.id_paket
	union all
	select sum(harga) jumlah,'0' diskon from tb_pesanan_workshop where id_siswa='$id_siswa'
	and id_acara in (select id_acara from tb_acara_workshop where id_siswa='$id_siswa')
    union all
	select '0' total,diskon from tb_siswa_diskon where id_siswa='$id_siswa'
	) a";
$rt=mysql_query($sql);
$total=@mysql_result($rt,0,"total");
$diskon=@mysql_result($rt,0,"diskon");

$sql_acara = "SELECT p.id_acara, p.id_siswa, q.id_siswa, r.id_acara FROM tb_acara_workshop p, tb_siswa q, p_acara r WHERE p.id_acara = r.id_acara AND p.id_siswa = q.id_siswa AND p.id_siswa = '$id'";
$query_acara = mysql_query($sql_acara);
$data_acara = mysql_fetch_array($query_acara);

$total_ppn = $total - $diskon;
$ppn = $total_ppn * 0.10;

if($data_acara['id_acara'] == '25') {
?>
<tr><td>Total Biaya (- diskon)</td><td colspan=2>: Rp. <?=number_format((($total - $diskon) * 0.10) + ($total-$diskon),0)?></td></tr>
<?  
} else {
?>
<tr><td>Total Biaya (- diskon)</td><td colspan=2>: Rp. <?=number_format($total-$diskon,0)?></td></tr>
<?
}
$sql="select sum(nilai) total_bayar from tb_siswa_bayar where id_siswa='$id_siswa'";
$rt=mysql_query($sql);
$total_bayar=@mysql_result($rt,0,"total_bayar");
?>
<tr><td>Total Bayar</td><td colspan=2>: Rp. <?=number_format($total_bayar,0)?></td></tr>

<?php if($data_acara['id_acara'] == '25') { ?>
<tr><td>Sisa Bayar</td><td colspan=2>: Rp. <?=number_format($total-$diskon-$total_bayar+$ppn,0)?></td></tr>
<?php } else { ?>
<tr><td>Sisa Bayar</td><td colspan=2>: Rp. <?=number_format($total-$diskon-$total_bayar,0)?></td></tr>
<? } ?>
</table><br>
<? } ?>
		
<form name="form" method="post" action="<?="?menu=$menu&uid=$uid&page=$page&act=proses&id_siswa=$id_siswa";?>">
<table>
<tr><td nowrap>Tanggal Bayar</td>
<td><input type='text' name='tgl_bayar' id='tgl_bayar' size='11' value='<?=$tgl_bayar?>'>
   	<script type="text/javascript">//<![CDATA[
      var cal = Calendar.setup({
          onSelect: function(cal) { cal.hide() }
      });
      cal.manageFields("tgl_bayar", "tgl_bayar", "%Y-%m-%d");
     </script>
   
   </td></tr>
<tr><td>Nilai</td><td><input type="text" name="nilai"></td></tr>
<tr><td>Keterangan</td><td><textarea rows=2 cols=30 name="keterangan"></textarea></td></tr>
<tr><td>Nama Pembayar</td><td><input type="text" name="pembayar"></td></tr>
<tr><td>Catatan</td><td><textarea rows=3 cols=30 name="catatan"></textarea></td></tr>
<tr><td colspan=2 align=center><input type="submit" value="simpan" name="tombol"></td></tr>
<tr><td colspan=2 align=center><a href="<?="?menu=$menu&uid=$uid&page=payment_workshop";?>" > 
<img src="images/back2.png" width="100" height="75"></a> </td></tr>
</form>
<?

if($act=="proses"){
$keterangan = str_replace("'","''",$keterangan);
$keterangan = nl2br($keterangan);
$keterangan = stripslashes($keterangan);

$catatan = str_replace("'","''",$catatan);
$catatan = nl2br($catatan);
$catatan = stripslashes($catatan);

$sql="insert into tb_siswa_bayar values ('$id_siswa',null,'$tgl_bayar','$nilai','$keterangan','$pembayar','$catatan','$SAH[id_user]', '$REMOTE_ADDR',' $sekarang','$no_urut','$no_kw')";
//echo "<br>$sql";
mysql_query($sql);
$act=null;
}

if(!$act){

$sql = "select date_format(tanggal,'%d-%m-%Y') tgl_bayar, nilai, keterangan,id_siswa,id_bayar,catatan, 
concat(date_format(tanggal,'%Y%m'),'-',no_kw) no_kwitansi,created
from tb_siswa_bayar where id_siswa='$id_siswa' order by created desc";
$rk = mysql_query($sql);
//$row = mysql_fetch_array($rk);
echo "<table width='500' cellspacing='1' cellpadding='3'>";
echo "<tr align=center bgcolor='#A7A7A7' height='25'>";
echo "<td><b>No</td><td><b>Tanggal</td><td>Nilai</td><td>Keterangan</td><td>Catatan</td><td>No-Kwitansi</td><td>ID-Client</td><td>Created</td><td><img src='images/Printer.png' border=0></td><td><img src='images/edit.gif' border=0></td></tr>";
for ($k=0;$k<@mysql_num_rows($rk);$k++){
$ccc++;
    if ($ccc%2 > 0){ $color="#EBEFFA"; }else{ $color="#D7E0F4"; };
    echo "
      <tr bgcolor='$color' onmouseover='bgColor=\"#FDD0D8\"' onmouseout='bgColor=\"$color\"' valign=top>
          <td align='center'>".($ccc)."</td>";?>
<td align=center><?=mysql_result($rk,$k,"tgl_bayar")?></td>
<td align=right><?=number_format(mysql_result($rk,$k,"nilai"),0)?></td>
<td><?=mysql_result($rk,$k,"keterangan")?></td>
<td><?=mysql_result($rk,$k,"catatan")?></td>
<td><?=mysql_result($rk,$k,"no_kwitansi")?></td>
<td><?=mysql_result($rk,$k,"id_siswa")?></td>
<td><?=mysql_result($rk,$k,"created")?></td>
<td align=center>
<? $id_siswa=mysql_result($rk,$k,"id_siswa");
	$id_bayar=mysql_result($rk,$k,"id_bayar");
	echo "<a href=\"javascript:void(window.open('cetak_bukti_workshop.php?id_siswa=$id_siswa&id_bayar=$id_bayar&id_user=$SAH[id_user]&login_ip=$REMOTE_ADDR&created=$sekarang&no_kw=".mysql_result($rk,$k,"no_kwitansi")."&printed=$sekarang','',''))\">"; ?><img border=0 src='images/Printer.png'></a></td>
<td align=center>
<? $id_siswa=mysql_result($rk,$k,"id_siswa");
	$id_bayar=mysql_result($rk,$k,"id_bayar");
	echo "<a href=?menu=$menu&uid=$uid&page=siswa_nota_edit&id_siswa=$id_siswa&id_bayar=$id_bayar&tanggal=$tgl_bayar&tno_urut=$no_urut&no_kw=$no_kw>"?><img border=0 src='images/edit.gif'></a></td>
	
</tr>
<?
}
echo "</table>";
}
?>