<?php

$db_host = "localhost";
$db_user = "h67649_liza642";
$db_pass = "telkom135";
$db_name = "h67649_liza642";

$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if(mysqli_connect_errno()){
	echo 'Gagal melakukan koneksi ke Database : '.mysqli_connect_error();
}   

$tanggal_hari_ini = date("d");
$jarak_reminder	  = 2;
$tanggal_reminder = $tanggal_hari_ini - $jarak_reminder;


$today = date("m-$tanggal_reminder");

$query  = "SELECT * FROM jadwal_fitting_new WHERE tgl_janji_akhir LIKE '%$today%' ";

$result = mysqli_query($koneksi, $query);

$row = mysqli_fetch_array($result);

$cek = mysqli_num_rows($result);

?>