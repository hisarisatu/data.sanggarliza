<?php
include "koneksi.php";

if(mysqli_connect_errno()){
	echo 'Gagal melakukan koneksi ke Database : '.mysqli_connect_error().'call Marvin Priyatno';
}
    $date = date('Y-m-d');
	$query1="SELECT *,DATE_ADD(tgl_janji_akhir, INTERVAL -2 DAY) as deadline, DATEDIFF(DATE_ADD(tgl_janji_akhir, INTERVAL 0 DAY), CURDATE()) as selisih FROM jadwal_fitting_new WHERE DATEDIFF(DATE_ADD(tgl_janji_akhir, INTERVAL 0 DAY), CURDATE()) >= '1' AND DATEDIFF(DATE_ADD(tgl_janji_akhir, INTERVAL 0 DAY), CURDATE()) <= '2'";
    $daftar=mysqli_query($koneksi, $query1) or die (mysqli_error());
    
    $laporan="<h4><b>List Nama Pengantin yang akan Fitting 2 Hari Lagi 2 Hari Lagi</b></h4>";
    $laporan .="<br/>";
	$laporan .="<table width=\"100%\" border=\"1\" align=\"center\" cellpadding=\"3\" cellspacing=\"0\">";
	$laporan .="<tr style=\"color: blue;\">";
	$laporan .="<td>ID CLIENT</td><td>TGL JANJI AWAL</td><td>Tanggal Janji Akhir</td><td>Barang Yang Harus Disiapkan</td><td>Keterangan</td> ";
	$laporan .="</tr>";
	while($dataku=mysqli_fetch_object($daftar))
	{
		$laporan .="<tr>";
		$laporan .="<td>$dataku->id_client</td><td>$dataku->tgl_janji_awal</td><td>$dataku->tgl_janji_akhir</td><td>$dataku->barang</td><td>$dataku->keterangan</td>";
		$laporan .="</tr>";
	}
	$laporan .="</table>";
    $laporan .="<h5><a href='#'><b>Untuk detail klik link ini, untuk login gunakan User dan Pass anda</b></a></h5>";
    
    require_once("phpmailer/class.phpmailer.php");
    require_once("phpmailer/class.smtp.php");
    
    $sendmail = new PHPMailer();
    $sendmail->setFrom('admin@sanggarliza.com','Hakko Bio Richard'); //email pengirim
    $sendmail->addReplyTo('admin@sanggarliza.com','Hakko Bio Richard'); //email replay
    $sendmail->addAddress('zalfinm@gmail.com','Agus Haryadi'); //email tujuan
    $sendmail->AddBCC('zalfinm@protonmail.com');
    $sendmail->Subject = 'Daftar Jadwal Fitting  Pengantin deadline 2 hari lagi'; //subjek email
    $sendmail->Body=$laporan; //isi pesan dalam format laporan
    $sendmail->isHTML(true);
	if(!$sendmail->Send()) 
	{
		echo "Email gagal dikirim : " . $sendmail->ErrorInfo;  
	} 
	else 
	{ 
		echo "Email berhasil terkirim!";  
	}
?>